<script setup lang="ts">
import AppLogoIcon from '@/components/AppLogoIcon.vue';
</script>

<template>
    <div class="max-w-[150px] w-full">
        <AppLogoIcon class="w-full" />
    </div>
</template>
